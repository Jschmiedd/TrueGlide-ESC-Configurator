@echo off
chcp 65001 >nul
echo Envoi des 2 corrections "flash" sur ton fork Jschmiedd/esc-configurator
echo.
cd /d "%~dp0"
if not exist pr3-flash-failure-null.patch goto nopatch
if not exist pr4-flash-watchdog.patch goto nopatch
if not exist esc-configurator git clone https://github.com/Jschmiedd/esc-configurator.git || goto err
cd esc-configurator
git config user.name Jschmiedd
git config user.email jschmiedd@gmail.com
git remote add upstream https://github.com/stylesuxx/esc-configurator.git 2>nul
git fetch upstream develop || goto err
git fetch origin fix/retry-async-rejection || goto err
git checkout -B fix/flash-failure-resolves-null upstream/develop || goto err
git am ..\pr3-flash-failure-null.patch || goto erram
git push -u origin fix/flash-failure-resolves-null || goto err
git checkout -B fix/flash-stall-watchdog origin/fix/retry-async-rejection || goto err
git am ..\pr4-flash-watchdog.patch || goto erram
git push -u origin fix/flash-stall-watchdog || goto err
echo.
echo ==========================================================
echo TERMINE : les 2 corrections "flash" sont sur ton fork.
echo ==========================================================
pause
exit /b 0
:nopatch
echo ERREUR : les 2 fichiers .patch doivent etre dans le meme dossier.
pause
exit /b 1
:erram
git am --abort
:err
echo.
echo ERREUR : envoie une capture de cette fenetre.
pause
exit /b 1
