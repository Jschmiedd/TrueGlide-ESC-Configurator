@echo off
chcp 65001 >nul
echo Envoi des 2 corrections sur ton fork Jschmiedd/esc-configurator
echo.
cd /d "%~dp0"
if not exist pr1-retry.patch goto nopatch
if not exist pr2-queue-timeout.patch goto nopatch
if not exist esc-configurator git clone https://github.com/Jschmiedd/esc-configurator.git || goto err
cd esc-configurator
git config user.name Jschmiedd
git config user.email jschmiedd@gmail.com
git remote add upstream https://github.com/stylesuxx/esc-configurator.git 2>nul
git fetch upstream develop || goto err
git checkout -B fix/retry-async-rejection upstream/develop || goto err
git am ..\pr1-retry.patch || goto erram
git push -u origin fix/retry-async-rejection || goto err
git checkout -B fix/queue-timeout-from-transmit upstream/develop || goto err
git am ..\pr2-queue-timeout.patch || goto erram
git push -u origin fix/queue-timeout-from-transmit || goto err
echo.
echo ==========================================================
echo TERMINE : les 2 corrections sont sur ton fork.
echo Envoie une capture de cette fenetre a Claude.
echo ==========================================================
pause
exit /b 0
:nopatch
echo ERREUR : les fichiers pr1-retry.patch et pr2-queue-timeout.patch
echo doivent etre dans le meme dossier que ce fichier.
pause
exit /b 1
:erram
git am --abort
:err
echo.
echo ERREUR : envoie une capture de cette fenetre a Claude.
pause
exit /b 1
