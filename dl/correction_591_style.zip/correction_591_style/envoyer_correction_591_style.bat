@echo off
chcp 65001 >nul
echo Mise a jour de la PR #591 (style demande par Chris) sur ton fork
echo.
cd /d "%~dp0"
if not exist pr591-review-style.patch goto nopatch
if not exist esc-configurator git clone https://github.com/Jschmiedd/esc-configurator.git || goto err
cd esc-configurator
git config user.name Jschmiedd
git config user.email jschmiedd@gmail.com
git fetch origin fix/settings-merge-and-flash-failed || goto err
git checkout -B fix/settings-merge-and-flash-failed origin/fix/settings-merge-and-flash-failed || goto err
git am ..\pr591-review-style.patch || goto erram
git push origin fix/settings-merge-and-flash-failed || goto err
echo.
echo ==========================================================
echo TERMINE : la PR #591 est mise a jour.
echo ==========================================================
pause
exit /b 0
:nopatch
echo ERREUR : le fichier pr591-review-style.patch doit etre dans le meme dossier.
pause
exit /b 1
:erram
git am --abort
:err
echo.
echo ERREUR : envoie une capture de cette fenetre.
pause
exit /b 1
