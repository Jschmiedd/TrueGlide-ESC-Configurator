@echo off
chcp 65001 >nul
echo Mise a jour des PR #588 et #592 (demande de Chris) sur ton fork
echo.
cd /d "%~dp0"
if not exist pr588-review-await.patch goto nopatch
if not exist esc-configurator git clone https://github.com/Jschmiedd/esc-configurator.git || goto err
cd esc-configurator
git config user.name Jschmiedd
git config user.email jschmiedd@gmail.com
git fetch origin fix/retry-async-rejection fix/flash-stall-watchdog || goto err
echo.
echo [1/2] PR 588
git checkout -B fix/retry-async-rejection origin/fix/retry-async-rejection || goto err
git am ..\pr588-review-await.patch || goto erram
git push origin fix/retry-async-rejection || goto err
echo.
echo [2/2] PR 592
git checkout -B fix/flash-stall-watchdog origin/fix/flash-stall-watchdog || goto err
git merge --no-edit fix/retry-async-rejection || goto errmerge
git push origin fix/flash-stall-watchdog || goto err
echo.
echo ==========================================================
echo TERMINE : les PR #588 et #592 sont mises a jour.
echo ==========================================================
pause
exit /b 0
:nopatch
echo ERREUR : le fichier pr588-review-await.patch doit etre dans le meme dossier.
pause
exit /b 1
:erram
git am --abort
goto err
:errmerge
git merge --abort
:err
echo.
echo ERREUR : envoie une capture de cette fenetre.
pause
exit /b 1
