@echo off
chcp 65001 >nul
echo Mise a jour de la PR #593 (demande de Chris) sur ton fork
echo.
cd /d "%~dp0"
if not exist pr593-review.patch goto nopatch
if not exist esc-configurator git clone https://github.com/Jschmiedd/esc-configurator.git || goto err
cd esc-configurator
git config user.name Jschmiedd
git config user.email jschmiedd@gmail.com
git fetch origin fix/connection-cleanup || goto err
git checkout -B fix/connection-cleanup origin/fix/connection-cleanup || goto err
git am ..\pr593-review.patch || goto erram
git log origin/fix/connection-cleanup..HEAD --format=%%an%%n%%ae%%n%%B | findstr /i "claude anthropic co-authored trueglide xpro" >nul && goto trace
git push origin fix/connection-cleanup || goto err
echo.
echo ==========================================================
echo TERMINE : la PR #593 est mise a jour.
echo ==========================================================
pause
exit /b 0
:nopatch
echo ERREUR : le fichier pr593-review.patch doit etre dans le meme dossier.
pause
exit /b 1
:trace
echo.
echo ARRET : trace d'IA ou de TrueGlide trouvee, rien n'a ete envoye.
git reset --hard origin/fix/connection-cleanup
pause
exit /b 1
:erram
git am --abort
:err
echo.
echo ERREUR : envoie une capture de cette fenetre.
pause
exit /b 1
