@echo off
chcp 65001 >nul
echo Envoi des 4 corrections sur ton fork Jschmiedd/esc-configurator
echo.
cd /d "%~dp0"
if not exist pr3-flash-watchdog.patch goto nopatch
if not exist pr4-log.patch goto nopatch
if not exist pr5-settings.patch goto nopatch
if not exist pr6-connection.patch goto nopatch
if not exist esc-configurator git clone https://github.com/Jschmiedd/esc-configurator.git || goto err
cd esc-configurator
git config user.name Jschmiedd
git config user.email jschmiedd@gmail.com
git remote add upstream https://github.com/stylesuxx/esc-configurator.git 2>nul
git fetch upstream develop || goto err
git fetch origin fix/retry-async-rejection fix/queue-timeout-from-transmit || goto err
echo.
echo [1/4] flash
git checkout -B fix/flash-stall-watchdog origin/fix/retry-async-rejection || goto err
git am ..\pr3-flash-watchdog.patch || goto erram
git push -u origin fix/flash-stall-watchdog || goto err
echo.
echo [2/4] journal
git checkout -B fix/keep-log-after-save upstream/develop || goto err
git am ..\pr4-log.patch || goto erram
git push -u origin fix/keep-log-after-save || goto err
echo.
echo [3/4] reglages
git checkout -B fix/settings-merge-and-flash-failed upstream/develop || goto err
git am ..\pr5-settings.patch || goto erram
git push -u origin fix/settings-merge-and-flash-failed || goto err
echo.
echo [4/4] connexion
git checkout -B fix/connection-cleanup origin/fix/queue-timeout-from-transmit || goto err
git am ..\pr6-connection.patch || goto erram
git push -u origin fix/connection-cleanup || goto err
echo.
echo ==========================================================
echo TERMINE : les 4 corrections sont sur ton fork.
echo ==========================================================
pause
exit /b 0
:nopatch
echo ERREUR : les 4 fichiers .patch doivent etre dans le meme dossier.
pause
exit /b 1
:erram
git am --abort
:err
echo.
echo ERREUR : envoie une capture de cette fenetre.
pause
exit /b 1
